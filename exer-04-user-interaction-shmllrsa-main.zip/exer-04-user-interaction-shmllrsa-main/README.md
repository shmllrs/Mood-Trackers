# Exercise 4 - CMSC 23

**Name:** Shamel Larosa <br/>
**Section:** UV-3L <br/>
**Student number:** 2023-06239 <br/>

## Code Description
This program is a mood tracker where it has default values but users get to interact with it since it needs name, nickname, age and others.

## Challenges encountered
I encountered a trouble when I was working on validating the name and age field.

## Solutions
At first, I didn't looked at the handout since there is a provided video recording for this exercise. But since I was having a hard time validating. I opted to look for the handout and it actually has the validation method at the very last part.

## References
- https://api.flutter.dev/flutter/rendering/SliverGridDelegateWithFixedCrossAxisCount-class.html
- https://stackoverflow.com/questions/52030797/making-a-dropdown-menu-in-flutter-with-a-map
- https://www.google.com/search?client=safari&rls=en&q=importing+ttf+font+in+flutter&ie=UTF-8&oe=UTF-8#fpstate=ive&vld=cid:5da42ae0,vid:7yqeC4__rlA,st:0
