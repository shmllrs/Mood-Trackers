import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

//extends widget (di nababago)
class MyApp extends StatelessWidget {
  //constructor for superclass key
  const MyApp({super.key});

  @override
  //override para makagawa ng widget
  Widget build(BuildContext context) {
    //returns app widget
    return MaterialApp(
      //not to show debug
      debugShowCheckedModeBanner: false,
      //title center below header
      //font is imported, set na sa pubspec.yaml
      title: 'Mood Tracker',
      theme: ThemeData(
        //color ng header
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(166, 255, 131, 212)),
        useMaterial3: true,
      ),
      //header title
      home: const MyHomePage(title: "Exercise 4"),
    );
  }
}

//extends widget (mababago pa)
class MyHomePage extends StatefulWidget {
  //constructor to pass sa stateful widget
  const MyHomePage({super.key, required this.title});
  //title
  final String title;

  @override
  //create object sa widget (di gagana kapag wala to)
  State<MyHomePage> createState() => _MyHomePageState();
}


class _MyHomePageState extends State<MyHomePage> {
  //text editing for name
  final TextEditingController _nameController = TextEditingController();
  //text editing for nickname
  final TextEditingController _nicknameController = TextEditingController();
  //text editing for age
  final TextEditingController _ageController = TextEditingController();
  //for validation
  final _formKey = GlobalKey<FormState>();
  //default exercise to true
  bool _exercisedToday = true;
  //default emotion
  String _defaultEmotion = "Joy";
  //default emotion level
  double _defaultEmotionLevel = 5.0;
  //default weather
  String _defaultWeather = "Sunny";

  //list for emotions
  static final List<String> _emotions = [
    "Joy", 
    "Sadness", 
    "Disgust", 
    "Fear", 
    "Anger", 
    "Anxiety", 
    "Embarrassment", 
    "Envy"
  ];

  //list for weathers
  static final List<String> _weathers = [
    "Sunny", 
    "Rainy", 
    "Stormy", 
    "Hailing", 
    "Snowy", 
    "Cloudy", 
    "Foggy", 
    "Partly Cloudy"
  ];


  @override
  //override since naka-override na sa state
  void dispose() {
    //clears name field
    _nameController.dispose();
    //clears nickname field
    _nicknameController.dispose();
    //clears age field
    _ageController.dispose();
    //total clear sa parent class sa state (myhomepage)
    super.dispose();
  }

  //return type for validation
  void _validateInput() {
    //check if the fields are valid
    if (_formKey.currentState!.validate()) {
      //kapag empty then di na isasama
      String nicknameText = _nicknameController.text.isNotEmpty ? "Nickname: ${_nicknameController.text}\n" : "";
      //alert message
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            //saved data title
            title: const Text("Saved Data"),
            content: Text(
              //return name
              "Name: ${_nameController.text}\n"
              //return nickname if meron
              "$nicknameText"
              //return age
              "Age: ${_ageController.text}\n"
              //return exercise if true or not
              "Exercised: $_exercisedToday\n"
              //return emotion
              "DefaultEmotion: $_defaultEmotion\n"
              //return emotion level
              "Strength: $_defaultEmotionLevel\n"
              //return weather
              "Weather: $_defaultWeather"
            ),
            actions: [
              TextButton(
                //closing
                onPressed: () => Navigator.pop(context),
                //button label
                child: const Text("OK"),
              ),
            ],
          );
        },
      );
    }
  }

  //reset
  void _resetFields() {
    //reset name
    _nameController.clear();
    //reset nickname
    _nicknameController.clear();
    //reset age
    _ageController.clear();
    setState(() {
      //balik sa dati mga default
      _exercisedToday = true;
      _defaultEmotion = "Joy";
      _defaultEmotionLevel = 5.0;
      _defaultWeather = "Sunny";
    });
  }

  //textfield widget
  Widget _buildTextField(String label, TextEditingController controller, {bool hasValidator = false, bool isNumeric = false}) {
    return TextFormField(
      //assigns controller (name, nickname, etc)
      controller: controller,
      //convert text to number
      keyboardType: isNumeric ? TextInputType.number : TextInputType.text,
      decoration: InputDecoration(
        //border sa text field
        border: const OutlineInputBorder(),
        //transparent label
        hintText: label,
      ),
      validator: hasValidator
          //validate if the name has inputted text or if the age has numeric number
          ? (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter $label';
              }
              if (isNumeric && double.tryParse(value) == null) {
                return 'Please enter a valid number';
              }
              return null;
            }
          : null,
    );
  }

  @override
  //override state widget (stateless)
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Align(
          //alignment of title
          alignment: Alignment.centerLeft,
          child: Text(widget.title),
        ),
      ),
      body: Padding(
        //padding sa edges
        padding: const EdgeInsets.all(10),
        child: Form(
          //validation
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Center(
                child: Text(
                  //style for centered title
                  'Mood Tracker',
                  style: TextStyle(
                    fontFamily: 'font',
                    fontSize: 45,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              //show name field
              _buildTextField("Name", _nameController, hasValidator: true),
              const SizedBox(height: 10),
              //show nickname field
              _buildTextField("Nickname", _nicknameController),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    //show age field
                    child: _buildTextField("Age", _ageController, hasValidator: true, isNumeric: true),
                  ),
                  const SizedBox(width: 10),
                  //title for the button
                  const Text("Exercised today"),
                  Switch(
                    //button set to default
                    value: _exercisedToday,
                    onChanged: (bool value) {
                      setState(() {
                        _exercisedToday = value;
                      });
                    },
                  ),
                ],
              ),
              const SizedBox(height: 10),
              GridView.builder(
                //emotions alignment
                shrinkWrap: true,
                //ref: https://api.flutter.dev/flutter/rendering/SliverGridDelegateWithFixedCrossAxisCount-class.html
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  //columns
                  crossAxisCount: 2,
                  //rows
                  childAspectRatio: 4,
                ),
                //get emotions if ilan
                itemCount: _emotions.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    //display emotion name
                    title: Text(_emotions[index]),
                    //show in radio type
                    leading: Radio<String>(
                      //radio value (joy etc)
                      value: _emotions[index],
                      //current value
                      groupValue: _defaultEmotion,
                      //update yung emotion
                      onChanged: (String? value) {
                        setState(() {
                          _defaultEmotion = value!;
                        });
                      },
                    ),
                  );
                },
              ),
              const SizedBox(height: 10),
              const Center(
                //question sliding range
                child: Text("How strong do you feel this Emotion?"),
              ),
              Slider(
                //default emotion set to 5
                value: _defaultEmotionLevel,
                //minimum is 1
                min: 1,
                //maximum 10
                max: 10,
                divisions: 9,
                //display rounded value na sa slide
                label: _defaultEmotionLevel.round().toString(),
                //update value
                onChanged: (double value) {
                  setState(() {
                    _defaultEmotionLevel = value;
                  });
                },
              ),
              const SizedBox(height: 8),
              const Center(
                //title choosing weather
                child: Text("Weather Today"),
              ),
              const SizedBox(height: 8),
              //drop down
              DropdownButtonFormField<String>(
                //naka-default sa sunny ang weather
                value: _defaultWeather,
                //outline lang like border
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
                //iterates sa weather list
                //ref: https://stackoverflow.com/questions/52030797/making-a-dropdown-menu-in-flutter-with-a-map
                items: _weathers.map((String weather) {
                  //return lang yung napiling weather
                  return DropdownMenuItem<String>(
                    value: weather,
                    child: Text(weather),
                  );
                }).toList(),
                //update
                onChanged: (String? newValue) {
                  setState(() {
                    _defaultWeather = newValue!;
                  });
                },
              ),
              const SizedBox(height: 8),
              //for save and reset button
              Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ElevatedButton(
                      //validate first
                      onPressed: _validateInput,
                      //save label
                      child: const Text("Save"),
                    ),
                    const SizedBox(width: 20),
                    ElevatedButton(
                      //reset
                      onPressed: _resetFields,
                      //reset label
                      child: const Text("Reset"),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
